
-- 16.0.0  Load and Unload Semi-Structured Data
--         Expect this lab to take approximately 40 minutes.

-- 16.1.0  Load Semi-Structured Parquet Data
--         This exercise will load a Parquet data file using different methods.
--         You will use small single file examples, so you will use a small
--         warehouse.

-- 16.1.1  Open a new worksheet and title it Semi-Structured Data and set the
--         context:

USE ROLE TRAINING_ROLE;
CREATE WAREHOUSE IF NOT EXISTS DOLPHIN_WH;
USE WAREHOUSE DOLPHIN_WH;
CREATE DATABASE IF NOT EXISTS DOLPHIN_DB;
USE DOLPHIN_DB.PUBLIC;


-- 16.1.2  Change your warehouse size to Small:

ALTER WAREHOUSE DOLPHIN_WH SET WAREHOUSE_SIZE=Small;


-- 16.1.3  Empty the REGION table:

CREATE OR REPLACE TABLE REGION (
  R_REGIONKEY NUMBER(38,0) NOT NULL,
  R_NAME VARCHAR(25) NOT NULL,
  R_COMMENT VARCHAR(152)
);


-- 16.1.4  Create a file format called MYPARQUETFORMAT. Set the TYPE to PARQUET,
--         and COMPRESSION to NONE:

CREATE FILE FORMAT MYPARQUETFORMAT
  TYPE = PARQUET
  COMPRESSION = NONE;


-- 16.1.5  Confirm that the region.parquet file is in the external stage:

LIST @training_db.traininglab.ed_stage/load/lab_files/ pattern='.*region.*';


-- 16.1.6  Query the data in the region.parquet file, without loading it first,
--         to see its format:

SELECT *
FROM @training_db.traininglab.ed_stage/load/lab_files/region.parquet
(FILE_FORMAT => MYPARQUETFORMAT);

--         You’ll find there is a single column, called $1.

-- 16.1.7  Click one of the records to open it. You will see a series of key-
--         value pairs with the keys called _COL_0, _COL_1, and _COL_2.

-- 16.1.8  Now, run a query to pull out just the values for the first key
--         (_COL_0) as a column, and cast the values to numbers:

SELECT
   $1:_COL_0::number
FROM @training_db.traininglab.ed_stage/load/lab_files/region.parquet
(FILE_FORMAT => MYPARQUETFORMAT);


-- 16.1.9  Note the alternate syntax for specifying the file format. You can
--         either use the syntax above, or FILE FORMAT = (FORMAT_NAME =
--         MYPARQUETFORMAT). They are equivalent.

-- 16.1.10 Write a query that returns values for all three (3) keys as columns.

-- 16.1.11 Cast each value to an appropriate type, and rename the columns to
--         something that seems to make sense based on the data in the table:

SELECT
$1:_COL_0::number AS region_id,
$1:_COL_1::VARCHAR(20) AS region_name,
$1:_COL_2::VARCHAR(150) AS comment
FROM @training_db.traininglab.ed_stage/load/lab_files/region.parquet
(FILE_FORMAT => MYPARQUETFORMAT);


-- 16.1.12 Use the query you just wrote as the basis of a COPY INTO command, to
--         load the REGION table from the region.parquet file:

COPY INTO REGION
FROM (SELECT
$1:_COL_0::number AS region_id,
$1:_COL_1::VARCHAR(20) AS region_name,
$1:_COL_2::VARCHAR(150) AS comment
FROM @training_db.traininglab.ed_stage/load/lab_files/region.parquet
(FILE_FORMAT => MYPARQUETFORMAT));


-- 16.1.13 View the data in the table:

SELECT * FROM REGION;


-- 16.2.0  Load Semi-Structured JSON Data
--         In this task you will load a table from a JSON file using three (3)
--         different methods.

-- 16.2.1  Create a new file format called MYJSONFORMAT. Set the TYPE to JSON,
--         and set STRIP_OUTER_ARRAY to TRUE.

CREATE FILE FORMAT MYJSONFORMAT
TYPE=JSON
STRIP_OUTER_ARRAY=TRUE;


-- 16.2.2  Create a new REGION1 table with a single column of type VARIANT:

CREATE TABLE region1 (record VARIANT);


-- 16.2.3  Confirm that the region.json file is in the external stage:

LIST @training_db.traininglab.ed_stage/load/lab_files/region.json;


-- 16.2.4  Load the table without specifying individual columns:

COPY INTO region1
FROM @training_db.traininglab.ed_stage/load/lab_files/region.json
FILE_FORMAT = (FORMAT_NAME = MYJSONFORMAT);


-- 16.2.5  Query the table to see what it contains:

SELECT * FROM region1;


-- 16.2.6  Click on one of the records to open it. What keys do you see in the
--         file that could be used as column names?

-- 16.2.7  Query directly from the file in the stage to see the values for the
--         R_NAME key.

SELECT $1:R_NAME
FROM @training_db.traininglab.ed_stage/load/lab_files/region.json
(FILE_FORMAT => MYJSONFORMAT);

--         Notice that the values shown are in quote marks. This means that
--         those values are of type VARIANT.

-- 16.2.8  Run the same query, but cast the value as a VARCHAR. See the
--         difference in output:

SELECT $1:R_NAME::VARCHAR(20)
FROM @training_db.traininglab.ed_stage/load/lab_files/region.json
(FILE_FORMAT => MYJSONFORMAT);


-- 16.2.9  Create a table called REGION2, with three columns (one for each key
--         that is found in each record of the table). Specify appropriate data
--         types (other than VARIANT) for each column:

CREATE TABLE REGION2 (
  R_NAME VARCHAR(20)
  , R_REGIONKEY INTEGER
  , R_COMMENT VARCHAR(150)
);


-- 16.2.10 Load the data into the REGION2 table by specifying the keys as
--         columns:

COPY INTO region2 FROM
(SELECT $1:R_NAME::VARCHAR(20),
$1:R_REGIONKEY::INTEGER,
$1:R_COMMENT::VARCHAR(150)
FROM @training_db.traininglab.ed_stage/load/lab_files/region.json
(FILE_FORMAT => MYJSONFORMAT));


-- 16.2.11 Query the REGION1 and REGION2 tables and compare their contents:

SELECT * FROM REGION1;
SELECT * FROM REGION2;


-- 16.2.12 Create a REGION3 table, specifying one column for each key in the
--         data file. Make sure that the column names in the table you create
--         exactly match (including case) the keys in the file. Specify an
--         appropriate data type (other than VARIANT) for each column:

CREATE TABLE region3 (R_REGIONKEY INT,
                      R_NAME VARCHAR,
                      R_COMMENT VARCHAR);


-- 16.2.13 Load the REGION3 table using the MATCH_BY_COLUMN_NAMES parameter:

COPY INTO region3
FROM @training_db.traininglab.ed_stage/load/lab_files/region.json
FILE_FORMAT = (FORMAT_NAME = MYJSONFORMAT)
MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE;

--         Notice that you do not need to specify columns to load, as long as
--         the keys in the file exactly match the column names in your table.
--         Also - as values are loaded, they are automatically cast from a
--         VARIANT data type, to the type specified for the column.

-- 16.2.14 List the stage and verify that it contains a file named
--         countrygeo.json:

ls @training_db.traininglab.ed_stage/load/lab_files/countrygeo.json;

--         In an earlier lab, you created a COUNTRYGEO table (as part of the
--         create table script).

-- 16.2.15 Describe this table to see the columns:

CREATE TABLE IF NOT EXISTS COUNTRYGEO (
  CG_NATIONKEY NUMBER(38,0),
  CG_CAPITAL   VARCHAR(100),
  CG_LAT       NUMBER(38,0),
  CG_LON       NUMBER(38,0),
  CG_ALTITUDE NUMBER(38,0)
);

DESCRIBE TABLE COUNTRYGEO;


-- 16.2.16 Select the data from this file (without loading it). Compare the
--         contents of the file with the table columns:

SELECT * FROM @training_db.traininglab.ed_stage/load/lab_files/countrygeo.json
(FILE_FORMAT => MYJSONFORMAT);


-- 16.2.17 Load the COUNTRYGEO table using MATCH_BY_COLUMN_NAME:

COPY INTO COUNTRYGEO FROM
@training_db.traininglab.ed_stage/load/lab_files/countrygeo.json
FILE_FORMAT = (FORMAT_NAME = MYJSONFORMAT)
MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE;


-- 16.2.18 Query the data in the table. What do you notice?

SELECT * FROM COUNTRYGEO;


-- 16.2.19 Write a COPY INTO that will load all of the data from the file into
--         the columns that exist in the COUNTRYGEO table.

TRUNCATE TABLE COUNTRYGEO;

COPY INTO COUNTRYGEO FROM
(SELECT $1:cg_altitude AS altitude, $1:cg_capital AS capital,
$1:cg_coord:cg_lat AS latitude,
$1:cg_coord:cg_lon AS longitude,
$1:cg_nationkey AS nationkey
FROM @training_db.traininglab.ed_stage/load/lab_files/countrygeo.json
(FILE_FORMAT => MYJSONFORMAT));

SELECT * FROM COUNTRYGEO;


-- 16.3.0  Unload Semi-Structured Data
--         Since you transformed the data when you loaded it into the REGION
--         tables, it is no longer in semi-structured format. In this task, you
--         will unload the data in csv, JSON, and Parquet formats.

-- 16.3.1  Create a named stage, DOLPHIN_unload, to hold the unloaded data:

create stage DOLPHIN_unload;


-- 16.3.2  Unload the data from the REGION3 table into the stage as a csv file
--         with fields delimited by the pipe character ( | ):

COPY INTO @DOLPHIN_unload
FROM region3
FILE_FORMAT = (TYPE = CSV FIELD_DELIMITER='|');


-- 16.3.3  List the contents of the stage. What is the default file naming
--         convention?

ls @DOLPHIN_unload;


-- 16.3.4  Unload the data from the REGION3 table into the stage, this time as a
--         standard csv file. Also specify a prefix for the file name by
--         including it with the stage name:

COPY INTO @DOLPHIN_unload/csv
FROM region3
FILE_FORMAT = (TYPE = CSV);


-- 16.3.5  List the contents of the stage again. What do you see?

ls @DOLPHIN_unload;


-- 16.3.6  Unload the data from the REGION3 table into the stage, as a JSON
--         file. What happens?

COPY INTO @DOLPHIN_unload
FROM REGION3
FILE_FORMAT = (TYPE = JSON);


-- 16.3.7  Unload the data from the REGION1 table into the stage, as a JSON
--         file. Why were you able to unload the data as JSON from REGION1, but
--         not from REGION3?

COPY INTO @DOLPHIN_unload
FROM REGION1
FILE_FORMAT = (TYPE = JSON)
OVERWRITE=TRUE;


-- 16.3.8  Unload the data from the REGION3 table into the stage, as a parquet
--         file. Resolve any issues that occur:

COPY INTO @DOLPHIN_unload
FROM REGION3
FILE_FORMAT = (FORMAT_NAME = MYPARQUETFORMAT)
OVERWRITE=TRUE;


-- 16.3.9  Using SnowSQL, download the files from the stage to your local
--         system. Examine each file to see what it contains:

GET @DOLPHIN_unload file:///<path to file>


-- 16.3.10 Drop the stage, and the tables REGION1, REGION2, and REGION3:

DROP STAGE CAMEL_unload;
DROP TABLE COUNTRYGEO;
DROP TABLE region1;
DROP TABLE region2;
DROP TABLE region3;

