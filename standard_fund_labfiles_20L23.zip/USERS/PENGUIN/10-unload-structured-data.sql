
-- 10.0.0  Unload Structured Data
--         Expect this lab to take approximately 30 minutes.

-- 10.1.0  Unload a Pipe-Delimited File to an Internal Stage

-- 10.1.1  Open a worksheet and set context:

USE ROLE TRAINING_ROLE;
CREATE WAREHOUSE IF NOT EXISTS PENGUIN_WH;
USE WAREHOUSE PENGUIN_WH;
CREATE DATABASE IF NOT EXISTS PENGUIN_DB;
USE PENGUIN_DB.PUBLIC;


-- 10.1.2  Create a fresh version of the REGION table with 5 records to unload:

create or replace table REGION as 
select * from SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.REGION;


-- 10.1.3  Unload the data to the REGION table stage. Remember that a table
--         stage is automatically created for each table. Use the slides,
--         workbook, or Snowflake documentation for questions on the syntax. You
--         will use MYPIPEFORMAT for the unload:

COPY INTO @%region
FROM region
FILE_FORMAT = (FORMAT_NAME = MYPIPEFORMAT);


-- 10.1.4  List the stage and verify that the data is there:

LIST @%region;


-- 10.1.5  Use GET to download the file to your local system. Open it with an
--         editor and see what it contains.
--         NOTE: The GET command is not supported in the GUI; use the SnowSQL
--         CLI:

GET @%region file:///<path to dir> ; -- this is for MAC
GET @%region file://c:<path to dir>; -- this is for windows


-- 10.1.6  Remove the file from the REGION table’s stage:

REMOVE @%region;


-- 10.2.0  Unload Part of a Table

-- 10.2.1  Create a new table from SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS:

CREATE TABLE new_orders AS
SELECT * FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS;


-- 10.2.2  Unload the columns o_orderkey, o_orderstatus, and o_orderdate from
--         your new table, into the table’s stage. Remember that a table stage
--         is automatically created for every table. Use the default file
--         format:

COPY INTO @%new_orders FROM
(SELECT o_orderkey, o_orderstatus, o_orderdate FROM new_orders);


-- 10.2.3  Verify the output is in the stage:

LIST @%new_orders;


-- 10.2.4  Use GET to download the file to your local system, and review it.
--         How many files did you get? At what point did COPY INTO decide to
--         split the files?

GET @%new_orders file:///<path> -- for Mac
GET @%new_orders file://c:<path -- For Windows


-- 10.2.5  Remove the files from the stage:

REMOVE @%new_orders;


-- 10.2.6  Repeat the unload with the selected columns, but this time specify
--         SINGLE=TRUE in your COPY INTO command. You might want to search the
--         documentation for this option to get more information on its use.
--         Also provide a name for the output file as part of the COPY INTO:

COPY INTO @%new_orders/new_orders.csv.gz FROM
(SELECT o_orderkey, o_orderstatus, o_orderdate FROM new_orders)
SINGLE=TRUE;


-- 10.2.7  Use GET to download the file to your local system, and review it:

GET @%new_orders file:///<path> -- for Mac
GET @%new_orders file://c:<path -- For Windows


-- 10.2.8  Remove the file from the stage:

REMOVE @%new_orders;


-- 10.3.0  JOIN and Unload a Table

-- 10.3.1  Do a SELECT with a JOIN on the REGION and NATION tables. You can JOIN
--         on any column you wish. Review the output from your JOIN.

SELECT * 
FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF1"."REGION" r 
JOIN "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF1"."NATION" n ON r.r_regionkey = n.n_regionkey;


-- 10.3.2  Create a named stage (you can call it whatever you want):

CREATE STAGE mystage;


-- 10.3.3  Unload the JOINed data into the stage you created:

COPY INTO @mystage FROM
(SELECT * FROM "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF1"."REGION" r JOIN "SNOWFLAKE_SAMPLE_DATA"."TPCH_SF1"."NATION" n
ON r.r_regionkey = n.n_regionkey);


-- 10.3.4  Verify the file is in the stage:

LIST @mystage;


-- 10.3.5  Use GET to download the file to your local system and review it:

GET @mystage file:///<path> -- for Mac
GET @mystage file://c:<path -- For Windows


-- 10.3.6  Remove the file from the stage:

REMOVE @mystage;


-- 10.3.7  Remove the stage:

DROP STAGE mystage;

