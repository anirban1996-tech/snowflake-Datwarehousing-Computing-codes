
-- 9.0.0   Use VALIDATION_MODE and ON_ERROR
--         Expect this lab to take approximately 10 minutes.

-- 9.1.0   Detect File Format Problems with VALIDATION_MODE
--         This exercise will use Snowflake’s VALIDATION_MODE option on a COPY
--         statement to demonstrate Snowflake’s pre-load error detection
--         mechanism.

-- 9.1.1   Open a new worksheet and name it Validate Data. Set the following
--         context:

USE ROLE TRAINING_ROLE;
CREATE WAREHOUSE IF NOT EXISTS INSTRUCTOR2_WH;
USE WAREHOUSE INSTRUCTOR2_WH;
CREATE DATABASE IF NOT EXISTS INSTRUCTOR2_DB;
USE INSTRUCTOR2_DB.PUBLIC;


-- 9.1.2   Create (or replace from previous labs) the REGION table to get ready
--         to load an empty table:

CREATE OR REPLACE TABLE REGION (
       R_REGIONKEY NUMBER(38,0) NOT NULL,
       R_NAME      VARCHAR(25)  NOT NULL,
       R_COMMENT   VARCHAR(152)
);


-- 9.1.3   Run a COPY command in validation mode against region_bad_1.tbl from
--         the external stage into the REGION table, and identify the issue that
--         will cause the load to fail:

COPY INTO region
FROM @training_db.traininglab.ed_stage/load/lab_files/
  FILES = ( 'region_bad_1.tbl' )
  FILE_FORMAT = ( FORMAT_NAME = MYPIPEFORMAT )
  VALIDATION_MODE = RETURN_ALL_ERRORS;

--         What happened?
--         To see what happened, expand the ERROR column in the query results.
--         To see the contents of that row, scroll all the way to the right and
--         click the linked text in the REJECTED_RECORD column. You can see in
--         the details that first column, which should contain a number, the
--         character is x.

-- 9.1.4   Run a COPY command in validation mode against region_bad_2.tbl from
--         the external stage into the REGION table. Identify the issue that
--         will cause the load to fail:

COPY INTO region FROM @training_db.traininglab.ed_stage/load/lab_files/
  FILES = ('region_bad_2.tbl')
  FILE_FORMAT = (FORMAT_NAME = MYPIPEFORMAT)
  VALIDATION_MODE = RETURN_ALL_ERRORS;

--         Why did it fail? And what does the data look like?

-- 9.2.0   Load Data with ON_ERROR Set to CONTINUE
--         This exercise will use Snowflake’s optional ON_ERROR parameter on the
--         COPY command to define the behavior Snowflake should exhibit if an
--         error is encountered when loading a file.

-- 9.2.1   Run a COPY command with the ON_ERROR parameter set to CONTINUE
--         against region_bad_1.tbl from the external stage into the REGION
--         Table:

COPY INTO REGION FROM @training_db.traininglab.ed_stage/load/lab_files/
  FILES = ( 'region_bad_1.tbl' )
  FILE_FORMAT = ( FORMAT_NAME = MYPIPEFORMAT )
  ON_ERROR = CONTINUE;


-- 9.2.2   In the query results pane, you will see that the status is
--         PARTIALLY_LOADED.

-- 9.2.3   Query the data that was loaded, and confirm that all rows were loaded
--         except the row that would not load according to the validation mode.
--         You should see that the row with REGIONKEY 1 is missing:

SELECT * FROM region;


-- 9.2.4   Truncate the REGION table:

TRUNCATE TABLE region;


-- 9.2.5   Run a COPY command with the ON_ERROR parameter set to CONTINUE
--         against region_bad_2.tbl:

COPY INTO region FROM @training_db.traininglab.ed_stage/load/lab_files/
  FILES = ('region_bad_2.tbl')
  FILE_FORMAT = (FORMAT_NAME = MYPIPEFORMAT)
  ON_ERROR = CONTINUE;


-- 9.2.6   View the data that was loaded and confirm that all rows were loaded
--         except the row the VALIDATION_MODE against this file stated would not
--         load (row 2). This time, REGIONKEY 2 is missing:

SELECT * FROM region;


-- 9.3.0   Reload the Region Table with Clean Data

-- 9.3.1   Truncate the REGION table:

TRUNCATE TABLE region;


-- 9.3.2   Validate that you have data in the table stage for your region table:

LIST @training_db.traininglab.ed_stage/load/lab_files/
  PATTERN='.*region.*';


-- 9.3.3   Load clean data to the REGION table:

COPY INTO region FROM @training_db.traininglab.ed_stage/load/lab_files/
  FILES = ('region.tbl.gz')
  FILE_FORMAT = ( FORMAT_NAME = MYGZIPPIPEFORMAT);


-- 9.3.4   View the data that was loaded and confirm that all 5 rows were
--         loaded.

SELECT * FROM region;


-- 9.3.5   Navigate to [Databases].

-- 9.3.6   Select INSTRUCTOR2_DB Database and confirm that every table has data
--         loaded.
