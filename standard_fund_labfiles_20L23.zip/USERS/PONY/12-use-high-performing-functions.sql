
-- 12.0.0  Use High-Performing Functions
--         expect this lab will take approximately 20 minutes.

-- 12.1.0  Use Approximate Count Functions

-- 12.1.1  Navigate to [Worksheets] and create a worksheet named *Function
--         Junction*.

-- 12.1.2  Alter the session so it does not use cached results:

ALTER SESSION SET use_cached_result=false;


-- 12.1.3  Set the Worksheet contexts as follows:

USE ROLE TRAINING_ROLE;
USE WAREHOUSE PONY_WH;
USE DATABASE SNOWFLAKE_SAMPLE_DATA;
USE SCHEMA TPCH_SF100;


-- 12.1.4  Change the virtual warehouse size to XSmall, then suspend and resume
--         the warehouse to clear any data in the warehouse cache:

ALTER WAREHOUSE PONY_WH
    SET WAREHOUSE_SIZE = 'XSmall';

ALTER WAREHOUSE PONY_WH SUSPEND;
ALTER WAREHOUSE PONY_WH RESUME;


-- 12.1.5  Use the query below to determine an approximate count with
--         Snowflake’s Hyperloglog high-performing function:

SELECT HLL(l_orderkey) FROM lineitem;


-- 12.1.6  Suspend and resume the warehouse again to clear the data cache.

-- 12.1.7  Execute the regular COUNT version of the query:

SELECT COUNT(DISTINCT l_orderkey) FROM lineitem;


-- 12.1.8  Compare the execution time of the two queries in steps 4 and 6.

-- 12.1.9  Note that the HLL approximate count version is much faster than the
--         regular count version.

-- 12.2.0  Use Percentile Estimation Functions
--         The APPROX_PERCENTILE function is the more efficient version of the
--         regular SQL MEDIAN function.

-- 12.2.1  Change your warehouse size to XLarge:

ALTER WAREHOUSE PONY_WH
    SET WAREHOUSE_SIZE = 'Xlarge';

ALTER WAREHOUSE PONY_WH SUSPEND;
ALTER WAREHOUSE PONY_WH RESUME;


-- 12.2.2  Start by using the SQL Median Function. Given the store_sales table
--         with over 28 billion rows, the following statement determines the
--         median store sales for each store identified in the store_sales
--         table:

USE SCHEMA SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10tcl;
SELECT MEDIAN(ss_sales_price), ss_store_sk
FROM store_sales
GROUP BY ss_store_sk;


-- 12.2.3  Review the query results returned, as well as the total duration time
--         the statement took to complete.
--         Query History Details - Median Function

-- 12.2.4  Run the Percentile Estimation Function on the same store_sales table
--         to find the approximate 50th percentile of store sales for each store
--         identified in the store_sales table:

USE SCHEMA SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10tcl;
SELECT APPROX_PERCENTILE(ss_sales_price, 0.5), ss_store_sk
FROM store_sales
GROUP BY ss_store_sk;


-- 12.2.5  Review the time it took to complete, and the value returned. Not only
--         was it faster, but it produced a result almost identical to that of
--         MEDIAN.
--         Query History Details - Median Approximate Function

-- 12.2.6  Change your warehouse size to XSmall:

ALTER WAREHOUSE PONY_WH
    SET WAREHOUSE_SIZE = 'XSmall';

ALTER WAREHOUSE PONY_WH SUSPEND;
ALTER WAREHOUSE PONY_WH RESUME;

