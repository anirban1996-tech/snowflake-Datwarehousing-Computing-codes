
-- 21.0.0  APPENDIX

-- 21.1.0  Commonly Used Commands
--         The following commands are used frequently throughout the course.
--         Because of that, they are listed here, rather than repeating them
--         individually for each step that uses them.
