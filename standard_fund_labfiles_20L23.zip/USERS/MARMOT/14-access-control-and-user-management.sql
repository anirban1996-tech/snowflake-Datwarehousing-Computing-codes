
-- 14.0.0  Access Control and User Management
--         Expect this lab to take approximately 40 minutes.
--         Lab Purpose: Students will work with the Snowflake security model and
--         learn how to create roles, grant privileges, build, and implement
--         basic security models.

-- 14.1.0  Determine Privileges (GRANTs)

-- 14.1.1  Navigate to [Worksheets] and create a new worksheet named Managing
--         Security.

-- 14.1.2  Run these commands to see what has been granted to you as a user, and
--         to your roles:

SHOW GRANTS TO USER MARMOT;
SHOW GRANTS TO ROLE TRAINING_ROLE;
SHOW GRANTS TO ROLE SYSADMIN;
SHOW GRANTS TO ROLE SECURITYADMIN;

--         NOTE: The TRAINING_ROLE has some specific privileges granted - not
--         all roles in the system would be able to see these results.

-- 14.2.0  Work with Role Permissions

-- 14.2.1  Change your role to SECURITYADMIN:

USE ROLE SECURITYADMIN;


-- 14.2.2  Create two new custom roles, called MARMOT_CLASSIFIED and
--         MARMOT_GENERAL:

CREATE ROLE MARMOT_CLASSIFIED;
CREATE ROLE MARMOT_GENERAL;


-- 14.2.3  GRANT both roles to SYSADMIN, and to your user:

GRANT ROLE MARMOT_CLASSIFIED, MARMOT_GENERAL TO ROLE SYSADMIN;
GRANT ROLE MARMOT_CLASSIFIED, MARMOT_GENERAL TO USER MARMOT;


-- 14.2.4  Change to the role SYSADMIN, so you can assign permissions to the
--         roles you created:

USE ROLE SYSADMIN;


-- 14.2.5  Create a warehouse named MARMOT_SHARED_WH:

CREATE WAREHOUSE MARMOT_SHARED_WH;


-- 14.2.6  Grant both new roles privileges to use the shared warehouse:

GRANT USAGE ON WAREHOUSE MARMOT_SHARED_WH
  TO ROLE MARMOT_CLASSIFIED;
GRANT USAGE ON WAREHOUSE MARMOT_SHARED_WH
  TO ROLE MARMOT_GENERAL;


-- 14.2.7  Create a database called MARMOT_CLASSIFIED_DB:

CREATE DATABASE MARMOT_CLASSIFIED_DB;


-- 14.2.8  Grant the role MARMOT_CLASSIFIED all necessary privileges to create
--         tables on any schema in MARMOT_CLASSIFIED_DB:

GRANT USAGE ON DATABASE MARMOT_CLASSIFIED_DB
TO ROLE MARMOT_CLASSIFIED;
GRANT USAGE ON ALL SCHEMAS IN DATABASE MARMOT_CLASSIFIED_DB
TO ROLE MARMOT_CLASSIFIED;
GRANT CREATE TABLE ON ALL SCHEMAS IN DATABASE MARMOT_CLASSIFIED_DB
TO ROLE MARMOT_CLASSIFIED;


-- 14.2.9  Use the role MARMOT_CLASSIFIED, and create a table called
--         SUPER_SECRET_TBL inside the MARMOT_CLASSIFIED_DB.PUBLIC schema:

USE ROLE MARMOT_CLASSIFIED;
USE MARMOT_CLASSIFIED_DB.PUBLIC;
CREATE TABLE SUPER_SECRET_TBL (id INT);


-- 14.2.10 Insert some data into the table:

INSERT INTO SUPER_SECRET_TBL VALUES (1), (10), (30);


-- 14.2.11 Assign GRANT SELECT privileges on SUPER_SECRET_TBL to the role
--         MARMOT_GENERAL:

GRANT SELECT ON SUPER_SECRET_TBL TO ROLE MARMOT_GENERAL;


-- 14.2.12 Use the role MARMOT_GENERAL to SELECT * from the table
--         SUPER_SECRET_TBL:

USE ROLE MARMOT_GENERAL;
SELECT * FROM MARMOT_CLASSIFIED_DB.PUBLIC.SUPER_SECRET_TBL;

--         What happens? Why?

-- 14.2.13 Grant role MARMOT_GENERAL usage on all schemas in
--         MARMOT_CLASSIFIED_DB:

USE ROLE SYSADMIN;
GRANT USAGE ON DATABASE MARMOT_CLASSIFIED_DB TO ROLE MARMOT_GENERAL;
GRANT USAGE ON ALL SCHEMAs IN DATABASE MARMOT_CLASSIFIED_DB TO ROLE MARMOT_GENERAL;


-- 14.2.14 Now try again:

USE ROLE MARMOT_GENERAL;
SELECT * FROM MARMOT_CLASSIFIED_DB.PUBLIC.SUPER_SECRET_TBL;


-- 14.2.15 Drop the database MARMOT_CLASSIFIED_DB:

USE ROLE SYSADMIN;
DROP DATABASE MARMOT_CLASSIFIED_DB;


-- 14.2.16 Drop the roles MARMOT_CLASSIFIED and MARMOT_GENERAL:

USE ROLE SECURITYADMIN;
DROP ROLE MARMOT_CLASSIFIED;
DROP ROLE MARMOT_GENERAL;

--         HINT: What role do you need to use to do this?

-- 14.3.0  Create Parent and Child Roles

-- 14.3.1  Change your role to SECURITYADMIN:

USE ROLE SECURITYADMIN;


-- 14.3.2  Create a parent and child role, and GRANT the roles to the role
--         SYSADMIN. At this point, the roles are peers (neither one is below
--         the other in the hierarchy):

CREATE ROLE MARMOT_child;
CREATE ROLE MARMOT_parent;
GRANT ROLE MARMOT_child, MARMOT_parent TO ROLE SYSADMIN;


-- 14.3.3  Give your user name privileges to use the roles:

GRANT ROLE MARMOT_child, MARMOT_parent TO USER MARMOT;


-- 14.3.4  Change your role to SYSADMIN:

USE ROLE SYSADMIN;


-- 14.3.5  Grant the following object permissions to the child role:

GRANT USAGE ON WAREHOUSE MARMOT_WH TO ROLE MARMOT_child;
GRANT USAGE ON DATABASE MARMOT_DB TO ROLE MARMOT_child;
GRANT USAGE ON SCHEMA MARMOT_DB.PUBLIC TO ROLE MARMOT_child;
GRANT CREATE TABLE ON SCHEMA MARMOT_DB.PUBLIC
   TO ROLE MARMOT_child;


-- 14.3.6  Use the child role to create a table:

USE ROLE MARMOT_child;
USE WAREHOUSE MARMOT_WH;
USE DATABASE MARMOT_DB;
USE SCHEMA MARMOT_DB.PUBLIC;
CREATE TABLE genealogy (name STRING, age INTEGER, mother STRING,
   father STRING);


-- 14.3.7  Verify that you can see the table:

SHOW TABLES LIKE '%genealogy%';


-- 14.3.8  Use the parent role and view the table:

USE ROLE MARMOT_parent;
SHOW TABLES LIKE '%genealogy%';

--         You will not see the table, because the parent role has not been
--         granted access.

-- 14.3.9  Change back to the SECURITYADMIN role and change the hierarchy so the
--         child role is beneath the parent role:

USE ROLE SECURITYADMIN;
GRANT ROLE MARMOT_child to ROLE MARMOT_parent;


-- 14.3.10 Use the parent role, and verify the parent can now see the table
--         created by the child:

USE ROLE MARMOT_parent;
SHOW TABLES LIKE '%genealogy%';

