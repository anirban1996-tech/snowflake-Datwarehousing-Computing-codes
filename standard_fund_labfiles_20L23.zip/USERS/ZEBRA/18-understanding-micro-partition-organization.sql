
-- 18.0.0  Understanding Micro-Partition Organization
--         In this exercise you will gain an understanding of the micro
--         partition organization of the table translates into effective query
--         performance. In particular, you’ll explore and find what it means to
--         query a table with predicates on columns that are part of the cluster
--         key (defined by the CLUSTER BY) and ones that are not (Natural
--         Clustering).
--         NOTE: Snowflake has specific guidance on when to cluster tables and
--         it is not intended for all tables. In general, large multi terabyte
--         tables are the typical candidates and it’s recommended to test using
--         representative queries. This lab shows how to test those
--         representative queries.

-- 18.1.0  Query using Filter and Group By
--         In analytic reports, it’s common to do aggregations such as SUM’s and
--         COUNT’s with a filter (ie, WHERE clause) and group by columns. These
--         traditional OLAP style queries are the core of typical analytic
--         workloads and access patterns.
--         We’ll first understand how the micro-partitions organization of our
--         table affects our query performance. Our table ORDERS_NATURAL, as is
--         the default in Snowflake, is organized by it’s natural ingestion
--         order. This provides generally good performance, as data is typically
--         ingested at the time it was created and time tends to be a good way
--         to organize many types of data. Not always, though.
--         Let’s first understand how well our common query, with it’s WHERE
--         clause filter predicates and GROUP BY columns perform on our table as
--         it’s organized now.

-- 18.1.1  Setup the context for this exercise.

-- 18.1.2  Open a new worksheet and execute the following SQL:

create warehouse if not exists ZEBRA_WH;
create database  if not exists ZEBRA_DB;
create schema if not exists ZEBRA_DB.PERF_TEST;
use ZEBRA_DB.PERF_TEST;


-- 18.1.3  To ensure that we’re not going to get any errant results, because we
--         had run a query previously, and to ensure that we’re not getting
--         results from other students in the class, disable the Query Result
--         cache in your session:

alter session set USE_CACHED_RESULT = false;

--         Our table ORDERS_NATURAL has 1.5B (that’s Billion with a B) rows in
--         it, and we want to get count of those rows by priority after July 1,
--         1997. Notice that our WHERE clause uses o_orderdate and the GROUP BY
--         clause is using o_orderpriority.

select
    o_orderpriority, count(*)
from
    TRAINING_DB.TRAININGLAB.ORDERS_NATURAL
where
    o_orderdate >= '1997-07-01'
group by
    o_orderpriority
order by
    o_orderpriority;


-- 18.1.4  Note the total amount of time it took to run this query.
--         Snowflakes partition pruning, or the ability for Snowflake to avoid
--         scanning and reading parts of large tables, is a key for good query
--         performance on large tables. Open the query profiler for the query
--         you just ran. Notice that the TableScan operator scanned all N
--         partitions, effectively Snowflake was reading data from all the
--         micro-partitions in the 1.5B row table.
--         No Pruning

-- 18.2.0  Create an Identical Table with a CLUSTER KEY

-- 18.2.1  Let’s create a table with identical data, but change the way the way
--         that our micro-partitions are organized, and then examine the effect
--         this has on the same query from a performance perspective.

-- 18.2.2  Clone ORDERS_NATURAL to create a table in your own database named
--         ORDERS_CLUSTER_KEY for just our own login to make changes to:

create or replace table ZEBRA_DB.PERF_TEST.ORDERS_CLUSTER_KEY
    clone TRAINING_DB.TRAININGLAB.ORDERS_NATURAL;

--         Currently, the clone ORDERS_CLUSTER_KEY is identical in organization
--         to it’s source.

-- 18.2.3  Set CLUSTER BY on the table to our columns which are used frequently
--         in our queries: o_orderdate and o_orderpriority:

alter table ORDERS_CLUSTER_KEY
    CLUSTER BY (o_orderdate, o_orderpriority);

--         With a CLUSTER KEY set on the table, it’s eligible to be updated and
--         reorganized so it more closely matches the desired cluster key.
--         Snowflake has an automatic clustering service which runs continuously
--         without any intervention or scheduling required.

-- 18.2.4  Run the following query to determine if the tables data has been
--         reclustered:

SELECT
start_time, end_time, credits_used, num_bytes_reclustered, num_rows_reclustered
FROM
TABLE(information_schema.automatic_clustering_history(
    date_range_start=>dateadd(day, -1, current_timestamp()),
    date_range_end=>current_timestamp(),
    table_name=>'ORDERS_CLUSTER_KEY')
    );

--         NOTE: It’s likely that if you run this shortly after setting the key
--         you get ZERO rows in the output. It may take a few minutes for the
--         service to reorganize the table. Once you see rows in the above
--         output, you should continue on with the lab.

-- 18.2.5  Run the same query you did before, but this time point it at the
--         table you have set the cluster key to your common query predicates:

select
    o_orderpriority, count(*)
from
    ORDERS_CLUSTER_KEY
where
    o_orderdate >= '1997-07-01'
group by
    o_orderpriority
order by
    o_orderpriority;

--         Did the query performance approve any? All things being equal, this
--         query should shave performed better than the original table.

-- 18.2.6  Open the query profile for the query on ORDERS_CLUSTER_KEY and review
--         the performance statistics on the TableScan operator.
--         Better Pruning
--         What do you think is the driving reason why this second query
--         performed better? How many partitions of the table were scanned?

-- 18.3.0  System information for clustering
--         In the previous sections we were determining the cause and affect on
--         the cluster keys and then running queries to check how well the
--         tables would perform when accessing via those columns. There are also
--         functions that Snowflake provides to allow you to programatically
--         evaluate and see how well a table’s current organization matches your
--         desired keys.
--         This is a hypothetical evaluation: My table is what it is, but how
--         well is it organized by these two columns?

-- 18.3.1  Run a query to get the clustering information from Snowflake on the
--         original table. The query says how well organized for these two
--         columns is the table:

select system$CLUSTERING_INFORMATION(
    'TRAINING_DB.TRAININGLAB.ORDERS_NATURAL'
  , '(o_orderdate, o_orderpriority)'
);


-- 18.3.2  You’ll need to click on the result (which is a JSON object) to review
--         the data. You’ll see something that looks similar to this:
--         The output from the above query indicates table is poorly clustered
--         by these two columns:

-- 18.3.3  Let’s get the same telemetry for our table we have explicitly
--         clustered, ORDERS_CLUSTER_KEY. Again, how well organized is
--         ORDERS_CLUSTER_KEY for o_orderdate and o_orderpriority?

select system$CLUSTERING_INFORMATION(
    'ORDERS_CLUSTER_KEY'
  , '(o_orderdate, o_orderpriority)'
);


-- 18.3.4  You’ll need to click on the result (which is a JSON object) to review
--         the data. You’ll see something that looks similar to this:
--         The table is now well clustered by these two columns:

-- 18.4.0  BONUS (On Your Own)

-- 18.4.1  Review the two query profiles again… Can you determine the difference
--         in rows scanned (not partitions, but number of rows) produced by the
--         two TableScan operators?

-- 18.4.2  What happens if you reverse the order of the two columns? Does it
--         matter and do you get any results? What do you think would happen if
--         you changed the order in the CLUSTER KEY and then tried the query
--         again?
