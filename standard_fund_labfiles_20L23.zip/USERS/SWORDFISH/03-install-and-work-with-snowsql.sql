
-- 3.0.0   Install and Work with SNOWSQL
--         Lab Purpose: Install SnowSQL and run several queries directly through
--         the command-line tool. The final exercise provides you with practice
--         running SQL scripts through the Snowflake command line tool.
--         Expect this lab to take approximately 35 minutes.

-- 3.1.0   Install SnowSQL

-- 3.1.1   In the UI, click [Help] and then Download… to display the Downloads
--         Dialog.

-- 3.1.2   Download the SnowSQL (CLI) client appropriate for your platform.

-- 3.1.3   Follow the instructions and install SnowSQL on your machine.

-- 3.2.0   Run SQL Commands using SnowSQL

-- 3.2.1   In a terminal or Windows console, start SnowSQL interactively:
--         In the command above, -a specifies the name of the Snowflake account
--         you are connecting to (the instructor will provide you with the
--         account name). The -u parameter specifies your user name.

-- 3.2.2   Verify that your current role is set to your default of
--         TRAINING_ROLE:

SELECT CURRENT_ROLE();


-- 3.2.3   Create a SWORDFISH_TBL if you hadn’t already in SWORDFISH_DB. You may
--         have already created this table in a previous lab, but if not we’ll
--         create it now:

USE WAREHOUSE SWORDFISH_WH;
CREATE DATABASE IF NOT EXISTS SWORDFISH_DB;
use database SWORDFISH_DB;
CREATE OR REPLACE TABLE SWORDFISH_DB.PUBLIC.SWORDFISH_TBL (
  id NUMBER(38,0),
  name STRING(10),
  country VARCHAR(20),
  order_date DATE
);


-- 3.2.4   Insert the following three rows into the table you created earlier:

INSERT INTO SWORDFISH_TBL VALUES(2, 'A','UK', '11/02/2005');
INSERT INTO SWORDFISH_TBL VALUES(4, 'C','SP', '11/02/2005');
INSERT INTO SWORDFISH_TBL VALUES(3, 'C','DE', '11/02/2005');


-- 3.2.5   Insert several more rows using a single INSERT INTO statement:

INSERT INTO SWORDFISH_TBL VALUES
    (1, 'ORDERC007', 'JAPAN', '11/02/2005'),
    (7, 'ORDERF821', 'UK', '11/03/2005'),
    (12, 'ORDERB029', 'USA', '11/03/2005');


-- 3.2.6   Query the data in SWORDFISH_TBL and order it by ID:

SELECT * FROM SWORDFISH_TBL
ORDER BY id;

--         Following the syntax above, insert four rows of data into the MEMBERS
--         table you created earlier. The five columns are customer ID, first
--         name, last name, membership start date, and membership level. HINT:
--         Remember what schema this table is in!

INSERT INTO SWORDFISH_SCHEMA.members
VALUES
(103, 'Barbra', 'Streisand', '10/05/2019', 'silver'),
(95, 'Ray', 'Bradbury', '06/06/2006', 'bronze'),
(111, 'Daenerys', 'Targaryen', '2/4/2019', 'gold'),
(87, 'Homer', 'Simpson', '3/1/1998', 'gold');


-- 3.2.7   Return all rows and columns in the table:

SELECT * FROM SWORDFISH_SCHEMA.members;


-- 3.2.8   Exit the SnowSQL interface:

!exit


-- 3.3.0   Create and Use a Configuration File

-- 3.3.1   Open the SnowSQL configuration file with the editor of your choice:

-- 3.3.2   Uncomment the following lines that define your default account
--         connection, and add the appropriate values. Save and close the file:

accountname = [account]
rolename = TRAINING_ROLE
username = SWORDFISH
dbname = SWORDFISH_DB
schemaname = PUBLIC
warehousename = SWORDFISH_WH


-- 3.3.3   Log back in to SnowSQL without specifying a connection; it will use
--         the default:

snowsql


-- 3.3.4   Confirm you are logged in with the appropriate database, schema, and
--         warehouse (they will be listed before the command prompt). Also
--         verify your role:

SELECT CURRENT_ROLE();


-- 3.3.5   Exit from SnowSQL:

!exit


-- 3.3.6   Edit the configuration file again, and create a second connection
--         called SYSADMIN that will automatically log you in with sysadmin as
--         your role:

[connections.SYSADMIN]
accountname=[account]
username = SWORDFISH
password = [your_password]
rolename = SYSADMIN

--         NOTE: The role SYSADMIN does not have access to your database and
--         warehouse, so you don’t need to include those in the connection
--         definition.

-- 3.3.7   Connect to SnowSQL using the SYSADMIN connection:

snowsql -c SYSADMIN


-- 3.3.8   Verify you are logged in as the SYSADMIN role:

SELECT CURRENT_ROLE();


-- 3.3.9   Exit from SnowSQL:

!exit


-- 3.3.10  Determine whether the connection name is case-sensitive:

-- 3.4.0   Run a Script in SnowSQL

-- 3.4.1   Create a file called script.sql that contains the following:

USE ROLE TRAINING_ROLE;
USE WAREHOUSE SWORDFISH_WH;
USE DATABASE SWORDFISH_DB;
USE SCHEMA PUBLIC;
SELECT * FROM SWORDFISH_TBL;


-- 3.4.2   Start SnowSQL, pass it your script, and supply your password when
--         requested:

snowsql -f script.sql

--         NOTE: You must either be in the same location as your script when you
--         run it, or you must provide the full path to the script.

-- 3.4.3   You will see your output and then SnowSQL will exit.
