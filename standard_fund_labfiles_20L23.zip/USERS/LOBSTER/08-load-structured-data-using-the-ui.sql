
-- 8.0.0   Load Structured Data Using the UI
--         Expect this lab to take approximately 25 minutes.

-- 8.1.0   Create Tables and File Formats
--         This exercise will load the region.tbl file into a REGION table in
--         your Database. The region.tbl file which is already in the cloud is
--         pipe (|) delimited. It has no header and contains the following five
--         rows:
--         NOTE: There is a delimiter at the end of every line, which by default
--         is interpreted as an additional column by the COPY INTO statement.

-- 8.1.1   Navigate to [Worksheets] and create a new worksheet named Load
--         Structured Data. Use the following SQL to set the context:

USE ROLE TRAINING_ROLE;
CREATE WAREHOUSE IF NOT EXISTS LOBSTER_WH;
USE WAREHOUSE LOBSTER_WH;
CREATE DATABASE IF NOT EXISTS LOBSTER_DB;
USE LOBSTER_DB.PUBLIC;


-- 8.1.2   Execute all of the CREATE TABLE statements:

CREATE OR REPLACE TABLE REGION (
       R_REGIONKEY NUMBER(38,0) NOT NULL,
       R_NAME      VARCHAR(25)  NOT NULL,
       R_COMMENT   VARCHAR(152)
);

CREATE OR REPLACE TABLE NATION (
       N_NATIONKEY NUMBER(38,0) NOT NULL,
       N_NAME      VARCHAR(25)  NOT NULL,
       N_REGIONKEY NUMBER(38,0) NOT NULL,
       N_COMMENT   VARCHAR(152)
);

CREATE OR REPLACE TABLE SUPPLIER (
       S_SUPPKEY   NUMBER(38,0) NOT NULL,
       S_NAME      VARCHAR(25)  NOT NULL,
       S_ADDRESS   VARCHAR(40)  NOT NULL,
       S_NATIONKEY NUMBER(38,0) NOT NULL,
       S_PHONE     VARCHAR(15)  NOT NULL,
       S_ACCTBAL   NUMBER(12,2) NOT NULL,
       S_COMMENT   VARCHAR(101)
);

CREATE OR REPLACE TABLE PART (
       P_PARTKEY     NUMBER(38,0) NOT NULL,
       P_NAME        VARCHAR(55)  NOT NULL,
       P_MFGR        VARCHAR(25)  NOT NULL,
       P_BRAND       VARCHAR(10)  NOT NULL,
       P_TYPE        VARCHAR(25)  NOT NULL,
       P_SIZE        NUMBER(38,0) NOT NULL,
       P_CONTAINER   VARCHAR(10)  NOT NULL,
       P_RETAILPRICE NUMBER(12,2) NOT NULL,
       P_COMMENT     VARCHAR(23)
);

CREATE OR REPLACE TABLE PARTSUPP (
       PS_PARTKEY    NUMBER(38,0) NOT NULL,
       PS_SUPPKEY    NUMBER(38,0) NOT NULL,
       PS_AVAILQTY   NUMBER(38,0) NOT NULL,
       PS_SUPPLYCOST NUMBER(12,2) NOT NULL,
       PS_COMMENT    VARCHAR(199)
);

CREATE OR REPLACE TABLE CUSTOMER (
       C_CUSTKEY    NUMBER(38,0) NOT NULL,
       C_NAME       VARCHAR(25)  NOT NULL,
       C_ADDRESS    VARCHAR(40)  NOT NULL,
       C_NATIONKEY  NUMBER(38,0) NOT NULL,
       C_PHONE      VARCHAR(15)  NOT NULL,
       C_ACCTBAL    NUMBER(12,2) NOT NULL,
       C_MKTSEGMENT VARCHAR(10),
       C_COMMENT    VARCHAR(117)
);

CREATE OR REPLACE TABLE ORDERS (
       O_ORDERKEY      NUMBER(38,0) NOT NULL,
       O_CUSTKEY       NUMBER(38,0) NOT NULL,
       O_ORDERSTATUS   VARCHAR(1)   NOT NULL,
       O_TOTALPRICE    NUMBER(12,2) NOT NULL,
       O_ORDERDATE     DATE         NOT NULL,
       O_ORDERPRIORITY VARCHAR(15)  NOT NULL,
       O_CLERK         VARCHAR(15)  NOT NULL,
       O_SHIPPRIORITY  NUMBER(38,0) NOT NULL,
       O_COMMENT       VARCHAR(79)  NOT NULL
);

CREATE OR REPLACE TABLE LINEITEM (
       L_ORDERKEY      NUMBER(38,0) NOT NULL,
       L_PARTKEY       NUMBER(38,0) NOT NULL,
       L_SUPPKEY       NUMBER(38,0) NOT NULL,
       L_LINENUMBER    NUMBER(38,0) NOT NULL,
       L_QUANTITY      NUMBER(12,2) NOT NULL,
       L_EXTENDEDPRICE NUMBER(12,2) NOT NULL,
       L_DISCOUNT      NUMBER(12,2) NOT NULL,
       L_TAX           NUMBER(12,2) NOT NULL,
       L_RETURNFLAG    VARCHAR(1)   NOT NULL,
       L_LINESTATUS    VARCHAR(1)   NOT NULL,
       L_SHIPDATE      DATE         NOT NULL,
       L_COMMITDATE    DATE         NOT NULL,
       L_RECEIPTDATE   DATE         NOT NULL,
       L_SHIPINSTRUCT  VARCHAR(25)  NOT NULL,
       L_SHIPMODE      VARCHAR(10)  NOT NULL,
       L_COMMENT       VARCHAR(44)  NOT NULL
);

CREATE OR REPLACE TABLE COUNTRYGEO (
       CG_NATIONKEY NUMBER(38,0),
       CG_CAPITAL   VARCHAR(100),
       CG_LAT       NUMBER(20,10),
       CG_LON       NUMBER(20,10),
       CG_ALTITUDE  NUMBER(38,0)
);


-- 8.1.3   Create a file format called MYPIPEFORMAT, that will read the pipe-
--         delimited region.tbl file:

CREATE FILE FORMAT MYPIPEFORMAT
  TYPE = CSV
  COMPRESSION = NONE
  FIELD_DELIMITER = '|'
  FILE_EXTENSION = 'tbl'
  ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE;


-- 8.1.4   Create a file format called MYGZIPPIPEFORMAT that will read the
--         compressed version of the region.tbl file. It should be identical to
--         the MYPIPEFORMAT, except you will set COMPRESSION = GZIP.

CREATE FILE FORMAT MYGZIPPIPEFORMAT
 TYPE = CSV
 COMPRESSION = GZIP
 FIELD_DELIMITER = '|'
 FILE_EXTENSION = 'tbl'
 ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE;


-- 8.2.0   Load the region.tbl File
--         The files for this task have been pre-loaded into a location on AWS.
--         The external stage that points to that location has been created for
--         you. The stage is in the TRAININGLAB schema of the TRAINING_DB
--         database. In this task you will review the files in the stage, and
--         load them using the file formats you created.

-- 8.2.1   Review the properties of the stage:

DESCRIBE STAGE TRAINING_DB.TRAININGLAB.ED_STAGE;

--         NOTE: The file format defined in the stage is not quite right for
--         this data. In particular, the field delimiter is set to a comma. You
--         have two choices - you could either modify they file format
--         definition in the stage itself, or you could specify a different file
--         format with the COPY INTO command. You will use your MYPIPEFORMAT
--         file format.

-- 8.2.2   Confirm the file is in the external stage with the list command:

LIST @training_db.traininglab.ed_stage/load/lab_files/ pattern='.*region.*';


-- 8.2.3   Load the data from the external stage to the REGION table, using the
--         file format you created in the previous task:

COPY INTO REGION
FROM @training_db.traininglab.ed_stage/load/lab_files/
FILES = ('region.tbl')
FILE_FORMAT = (FORMAT_NAME = MYPIPEFORMAT);


-- 8.2.4   Select and review the data in the REGION table, either by executing
--         the following command in your worksheet or by using Preview Data in
--         the sidebar:

SELECT * FROM REGION;


-- 8.3.0   Load Text Files from an External Stage
--         This exercise will load tables from text files that are in an
--         external stage.

-- 8.3.1   Navigate to [Databases].

-- 8.3.2   Select the TRAINING_DB Database.

-- 8.3.3   Select the Stages tab from the list above the display area, and
--         confirm you can see the ED_STAGE Stage in the TRAININGLAB Schema.
--         This will show the stage but does not show you as much information as
--         the DESCRIBE STAGE command you used earlier.

-- 8.3.4   Navigate back to [Worksheets].

-- 8.3.5   List some other files in the TRAINING_DB.TRAININGLAB.ED_STAGE stage:

LS @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/;

--         Some of the larger tables include many files for loading. For these
--         larger tables you will get better performance using additional cores.
--         Therefore, for this load exercise you will use a larger warehouse.

-- 8.3.6   Increase the size of the warehouse to Medium:

ALTER WAREHOUSE LOBSTER_WH
SET WAREHOUSE_SIZE = Medium;


-- 8.3.7   Load the CUSTOMER table into the PUBLIC Schema using the same File
--         Format you used to load REGION in the first exercise.
--         NOTE: You will use the fully qualified name pointing to a table in
--         the database that you created. The FROM data is the Snowflake sample
--         data stored on the external stage.

COPY INTO LOBSTER_DB.PUBLIC.CUSTOMER
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/CUSTOMER
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = CONTINUE;


-- 8.3.8   Load the remaining tables (shown below) by running the same command
--         as above, but replacing CUSTOMER where it appears with the name of
--         the table you want to load:

COPY INTO LOBSTER_DB.PUBLIC.LINEITEM
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/LINEITEM/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';

COPY INTO LOBSTER_DB.PUBLIC.NATION
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/NATION/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';

COPY INTO LOBSTER_DB.PUBLIC.ORDERS
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/ORDERS/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';

COPY INTO LOBSTER_DB.PUBLIC.PART
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/PART/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';

COPY INTO LOBSTER_DB.PUBLIC.PARTSUPP
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/PARTSUPP/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';

COPY INTO LOBSTER_DB.PUBLIC.SUPPLIER
FROM @TRAINING_DB.TRAININGLAB.ED_STAGE/load/TCPH_SF10/SUPPLIER/
FILE_FORMAT = (FORMAT_NAME = LOBSTER_DB.PUBLIC.MYPIPEFORMAT)
ON_ERROR = 'CONTINUE';


-- 8.3.9   Explore the data in some of the tables you loaded:

SELECT * FROM lineitem LIMIT 100;
SELECT * FROM nation;
SELECT * FROM orders LIMIT 100;


-- 8.4.0   Load a GZip Compressed File
--         This exercise will reload the REGION Table from a gzip compressed
--         file that is in the external stage. You will use your
--         MYGZIPPIPEFORMAT file format.
--         For these next steps, you will use a smaller warehouse.

-- 8.4.1   Change the size of LOBSTER_WH to Small:

ALTER WAREHOUSE LOBSTER_WH SET WAREHOUSE_SIZE=Small;


-- 8.4.2   Empty the REGION Table in the PUBLIC schema of LOBSTER_DB:

TRUNCATE TABLE region;


-- 8.4.3   Confirm that the region.tbl.gz file is in the external stage:

LIST @training_db.traininglab.ed_stage/load/lab_files/ pattern='.*region.*';


-- 8.4.4   Reload the REGION table from the region.tbl.gz file. Review the
--         syntax of the COPY INTO command used in the previous task. Specify
--         the file to COPY as region.tbl.gz.

COPY INTO region
FROM @training_db.traininglab.ed_stage/load/lab_files/
FILES = ('region.tbl.gz')
FILE_FORMAT = ( FORMAT_NAME = MYGZIPPIPEFORMAT);


-- 8.4.5   Query the table to view the data:

SELECT * FROM region;

